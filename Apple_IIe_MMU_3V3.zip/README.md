# IMPORTANT
This repository contains design files for the Apple IIe's MMU custom IC. This is a "work in progress" and should not be used to produce adapters in its current state. This version is completely untested.

## Project status
This project is still in its prototype phase.
<br/>
![MMU](https://img.shields.io/badge/3.3_V_Apple_IIe_MMU-UNTESTED-red)<br/>

## The MMU Adapter
<a align="center">
    <img src="/resources/MMU_Raytraced.png" style="width: 480px"/>
</a>
<p><i>A rendering of the MMU, front and back</i></p>
